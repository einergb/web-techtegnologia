---
name: TechStore Colombia
colors:
  surface: '#f4faff'
  surface-dim: '#d4dbe0'
  surface-bright: '#f4faff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eef4fa'
  surface-container: '#e8eff4'
  surface-container-high: '#e2e9ee'
  surface-container-highest: '#dce3e9'
  on-surface: '#161d20'
  on-surface-variant: '#58413e'
  inverse-surface: '#2a3136'
  inverse-on-surface: '#ebf2f7'
  outline: '#8c716d'
  outline-variant: '#e0bfbb'
  surface-tint: '#ab342a'
  primary: '#a83128'
  on-primary: '#ffffff'
  primary-container: '#c9493d'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb4aa'
  secondary: '#136a63'
  on-secondary: '#ffffff'
  secondary-container: '#a2eee4'
  on-secondary-container: '#1b6e67'
  tertiary: '#785600'
  on-tertiary: '#ffffff'
  tertiary-container: '#976d00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad5'
  primary-fixed-dim: '#ffb4aa'
  on-primary-fixed: '#410001'
  on-primary-fixed-variant: '#8a1b15'
  secondary-fixed: '#a5f0e7'
  secondary-fixed-dim: '#89d4cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#00504a'
  tertiary-fixed: '#ffdea5'
  tertiary-fixed-dim: '#f3be53'
  on-tertiary-fixed: '#261900'
  on-tertiary-fixed-variant: '#5d4200'
  background: '#f4faff'
  on-background: '#161d20'
  surface-variant: '#dce3e9'
typography:
  display:
    fontFamily: Outfit
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Outfit
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  price-hero:
    fontFamily: Outfit
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  price-card:
    fontFamily: Outfit
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 26px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  code-metric:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.03em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

El diseño fusiona el dinamismo del retail tecnológico con la rigurosidad analítica de un dashboard operativo. El estilo se define como **Neo-Utilitario Tecnológico**: superficies limpias de alta legibilidad, geometría precisa y toques cromáticos intencionales inspirados en la vitalidad urbana y la flora andina de Colombia.

Evoca inmediatez, transparencia y solidez logística. La interfaz rechaza los artificios genéricos (degradados violetas, exceso de desenfoques) a favor de un ritmo visual estructurado, microinteracciones nítidas y una clara distinción entre el flujo de compra para el consumidor final y la densidad de datos requerida por el operador administrativo.

## Colors

La paleta cromática se articula a través de funciones estrictas:

- **Fondo Principal (`#F4F5F2`):** Marfil frío que atenúa la fatiga visual en sesiones prolongadas de administración y aporta calidez técnica a la tienda.
- **Superficie (`#FFFFFF`):** Base pura para tarjetas de producto, tablas de datos y paneles modulares.
- **Primario Coral (`#E45D4F`):** Reservado para conversiones críticas, llamadas a la acción (CTAs) de compra, alertas de ofertas y estados afirmativos clave.
- **Acento Secundario Verde Petróleo (`#26766F`):** Proporciona anclaje institucional en navegación activa, pestañas de control, métricas de inventario y filtros avanzados.
- **Tipografía Grafito (`#20272B`) y Gris Mineral (`#657174`):** Garantizan contraste AA/AAA para lectura ágil de especificaciones técnicas y trazabilidad operativa.
- **Funcionales:** Aviso Mostaza (`#D6A43B`) para alertas de stock bajo y despachos pendientes; Error Carmín (`#B94138`) para validaciones fallidas y devoluciones; Borde Técnico (`#DCE2DE`) para delimitar planos sin saturar.

## Typography

La arquitectura tipográfica equilibra el carácter visual y la densidad técnica:

- **Outfit (Display & Encabezados):** Aporta modernidad geométrica y dinamismo en títulos de categoría, nombres de dispositivos y banners destacados. Se emplea con pesos 600 y 700 para transmitir contundencia.
- **Hanken Grotesk (Cuerpo, Tablas y Etiquetas):** Tipografía compacta y neutral que maximiza la legibilidad en fichas de especificaciones, métricas operativas y paneles de órdenes.
- **Formateo de Precios en COP:** Siempre se presentan con espacio estricto y formato localizado: `$ 249.900 COP`. La cifra numérica utiliza `Outfit` semi-bold/bold para una distinción inmediata frente al etiquetado secundario.

## Layout & Spacing

El sistema emplea un modelo de **cuadrícula fluida modular**:

- **Desktop (>= 1200px):** Cuadrícula de 12 columnas con márgenes exteriores de `2rem` (32px) y canales (`gutter`) de `1.5rem` (24px). El dashboard organiza navegación lateral fija (260px) con área central extensible.
- **Tablet (768px - 1199px):** Cuadrícula de 8 columnas. La barra lateral de administración colapsa a modo de iconos o panel emergente deslizante.
- **Mobile (< 768px):** Cuadrícula de 4 columnas con márgenes de `1rem` (16px) y medianiles de `1rem`. Las tarjetas de catálogo se muestran en cuadrícula de 2 columnas o carruseles horizontales snap.
- **Ritmo Espacial:** Todo espacio interno respeta la escala base de 4px/8px para garantizar alineaciones compactas en tablas de inventario y holgadas en la experiencia de compra.

## Elevation & Depth

La tridimensionalidad se construye a través de **capas tonales y contornos de baja saturación**, priorizando la velocidad de escaneo y evitando sombras densas o turbias:

1. **Nivel Base (Fondo):** Superficie `#F4F5F2` que define el canvas global.
2. **Nivel 1 (Superficies Estructuradas):** Paneles, tarjetas y barras superiores en `#FFFFFF` delimitadas por un borde perimetral de `1px solid #DCE2DE`. No requiere sombra en reposo.
3. **Nivel 2 (Interacción & Elevación Ligera):** Al posar el cursor sobre tarjetas de producto o filas operativas, la superficie adquiere una sombra ambiental difusa: `0 4px 16px rgba(32, 39, 43, 0.06)` y el borde transiciona sutilmente hacia el color grafito medio.
4. **Nivel 3 (Modales, Filtros y Desplegables):** Capas flotantes con sombra profunda pero limpia: `0 12px 32px rgba(32, 39, 43, 0.12)`, contenidas por bordes nítidos de `1px solid #DCE2DE`.

## Shapes

La escala de curvatura se adhiere a un enfoque **Soft (`roundedness: 1`)**:

- **Radio Estándar (4px / 0.25rem):** Entradas de texto, checkboxes, celdas interactivas de tablas y botones compactos. Otorga precisión técnica sin caer en la dureza industrial pura.
- **Radio Medio (8px / 0.5rem - `rounded-lg`):** Tarjetas de producto, contenedores de métricas en dashboard, ventanas modulares y paneles de filtros.
- **Radio Superior (12px / 0.75rem - `rounded-xl`):** Contenedores destacados, banners principales de promociones y modales centrales.
- **Cápsulas (Pill, 9999px):** Exclusivo para badges de estado logístico, chips de filtros aplicados y tags de disponibilidad.

## Components

### Botones
- **Primario (Compra / Acción Principal):** Fondo `#E45D4F`, texto `#FFFFFF`, bordes nulos, esquinas de 4px (`roundedness: 1`). Al hover: fondo `#D34F41` con traslación sutil de -1px en el eje Y.
- **Secundario (Gestión / Navegación):** Fondo `#26766F`, texto `#FFFFFF`. Utilizado en acciones clave de administración (guardar cambios, exportar métricas).
- **Contorno (Filtros / Acciones Neutras):** Fondo transparente, borde `1px solid #DCE2DE`, texto `#20272B`. Al hover: fondo `#FFFFFF` y borde oscurecido.

### Tarjetas de Producto
- Superficie `#FFFFFF` con borde `1px solid #DCE2DE` y radio de 8px.
- Proporción simétrica para la imagen del producto sobre contenedor interno `#F4F5F2` acolchado.
- Jerarquía vertical obligatoria: Categoría/Marca (`label-sm`, `#657174`), Nombre de producto (`headline-sm`, `#20272B`), Calificación/Disponibilidad, y Precio destacado (`price-card`, `#20272B`).
- Botón rápido "Agregar" en tono Coral `#E45D4F` de ancho completo o icono lateral flotante.

### Badges & Chips
- **En Stock / Entregado:** Fondo `rgba(38, 118, 111, 0.12)`, texto `#26766F`.
- **Bajo Stock / En Preparación:** Fondo `rgba(214, 164, 59, 0.15)`, texto `#996E14`.
- **Agotado / Error Operativo:** Fondo `rgba(185, 65, 56, 0.12)`, texto `#B94138`.
- Geometría tipo cápsula con texto en `label-sm` semibold.

### Entradas de Datos & Formularios
- Altura estándar de 40px en desktop / 44px en mobile. Fondo `#FFFFFF`, borde perimetral `1px solid #DCE2DE` y esquinas de 4px.
- Estado Focus: borde `1px solid #26766F` con anillo de relieve tenue (`box-shadow: 0 0 0 3px rgba(38, 118, 111, 0.15)`).

### Filas y Tablas de Dashboard
- Encabezados de tabla en `#F4F5F2`, texto `#657174` en mayúsculas sostenidas (`11px`, tracking extendido).
- Filas alternadas con divisores limpios en `#DCE2DE`. Al interactuar (hover), la fila resalta en blanco con microborde lateral izquierdo de 3px en `#26766F`.